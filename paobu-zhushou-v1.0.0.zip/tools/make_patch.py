# -*- coding: utf-8 -*-
"""生成差量更新包（只包含有变化的文件）。

为什么需要它
------------
完整发布包 35 MB，但绝大多数版本升级只改了几个 .py 文件 ——
PyInstaller 把 Python 代码全塞进 `跑步助手.exe` 的 PYZ 里，
第三方库堆在 `_internal`，几周都不动一次。
所以「只换有变化的文件」能把 35 MB 压到 8 MB（甚至更小）。

用法
----
    # 1) 手上有旧安装目录（比如从 D:\\软件\\跑步助手 复制一份备份）
    python tools\\make_patch.py --old D:\\backup\\旧版 --new D:\\temp\\新版解包

    # 2) 只有新发布包也行：把旧版 zip 也交进来
    python tools\\make_patch.py --old-zip 旧.zip --new-zip 新.zip

产物
----
    跑步助手_补丁_<新版本>.zip
      ├── patch.json        # 文件清单 + 删除清单 + sha256
      └── <变化的文件…>

`tools\\update_runner.ps1` 检测到 patch.json 就自动走差量模式：
只覆盖包里带的文件、删掉清单里标记淘汰的文件，其余一律不动。
"""
import argparse
import hashlib
import json
import os
import shutil
import tempfile
import zipfile

# 不参与比较的路径（用户数据 / 运行期产物）
SKIP_TOP = {
    ".funsport", "version.json", "__pycache__",
    ".update_staging", ".update_backup", ".update_marker.json",
}
SKIP_EXT = (".pyc", ".pyo", ".log")


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _walk(root):
    """返回 {相对路径(正斜杠): (绝对路径, 大小)}，跳过用户数据与缓存。"""
    out = {}
    for base, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in ("__pycache__", ".git")]
        for name in files:
            abs_path = os.path.join(base, name)
            rel = os.path.relpath(abs_path, root).replace("\\", "/")
            top = rel.split("/", 1)[0]
            if top in SKIP_TOP:
                continue
            if name.lower().endswith(SKIP_EXT):
                continue
            out[rel] = (abs_path, os.path.getsize(abs_path))
    return out


def _read_version(root):
    """优先读 version.json，其次 funsport/__init__.py 里的 __version__。"""
    vj = os.path.join(root, "version.json")
    if os.path.exists(vj):
        try:
            with open(vj, encoding="utf-8") as fh:
                return str((json.load(fh) or {}).get("version") or "")
        except Exception:
            pass
    init = os.path.join(root, "funsport", "__init__.py")
    if os.path.exists(init):
        try:
            for line in open(init, encoding="utf-8"):
                if line.startswith("__version__"):
                    return line.split("=", 1)[1].strip().strip('"\'')
        except Exception:
            pass
    return ""


def make_patch(old_dir, new_dir, out_zip, notes=""):
    old = _walk(old_dir)
    new = _walk(new_dir)

    changed, added, same = [], [], []
    for rel, (abs_path, size) in new.items():
        if rel not in old:
            added.append(rel)
            changed.append(rel)
            continue
        old_abs, old_size = old[rel]
        if size != old_size:
            changed.append(rel)
            continue
        if _sha256(abs_path) != _sha256(old_abs):
            changed.append(rel)
        else:
            same.append(rel)

    removed = [rel for rel in old if rel not in new]

    manifest = {
        "kind": "patch",
        "from_version": _read_version(old_dir),
        "to_version": _read_version(new_dir),
        "notes": notes,
        "files": sorted(changed),
        "delete": sorted(removed),
        "sha256": {rel: _sha256(os.path.join(new_dir, rel)) for rel in changed},
        "stats": {
            "changed": len(changed), "added": len(added),
            "removed": len(removed), "same": len(same),
        },
    }

    if os.path.exists(out_zip):
        os.remove(out_zip)
    with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("patch.json",
                    json.dumps(manifest, ensure_ascii=False, indent=2))
        for rel in changed:
            zf.write(os.path.join(new_dir, rel), rel)
    return manifest, out_zip


def _unzip_to(zip_path, dest):
    with zipfile.ZipFile(zip_path) as zf:
        zf.extractall(dest)
    entries = [e for e in os.listdir(dest) if e != "__MACOSX"]
    if len(entries) == 1 and os.path.isdir(os.path.join(dest, entries[0])):
        return os.path.join(dest, entries[0])
    return dest


def main(argv=None):
    ap = argparse.ArgumentParser(description="生成跑步助手差量更新包")
    ap.add_argument("--old", help="旧安装目录（含 跑步助手.exe）")
    ap.add_argument("--new", help="新版本解包目录")
    ap.add_argument("--old-zip", help="旧版本发布 zip（会自动解包）")
    ap.add_argument("--new-zip", help="新版本发布 zip（会自动解包）")
    ap.add_argument("--out", help="输出的补丁 zip 路径")
    ap.add_argument("--notes", default="", help="更新说明")
    args = ap.parse_args(argv)

    work = tempfile.mkdtemp(prefix="fs_patch_")
    try:
        old_dir = args.old
        new_dir = args.new
        if args.old_zip and not old_dir:
            old_dir = _unzip_to(args.old_zip, os.path.join(work, "old"))
        if args.new_zip and not new_dir:
            new_dir = _unzip_to(args.new_zip, os.path.join(work, "new"))
        if not old_dir or not new_dir:
            print("× 必须给出 --old/--old-zip 与 --new/--new-zip")
            return 2
        for d in (old_dir, new_dir):
            if not os.path.isdir(d):
                print(f"× 目录不存在：{d}")
                return 2
            if not os.path.exists(os.path.join(d, "跑步助手.exe")):
                print(f"! 提示：{d} 里没有 跑步助手.exe，diff 结果可能不准")

        out = args.out
        if not out:
            ver = _read_version(new_dir) or "new"
            out = os.path.join(os.path.dirname(os.path.abspath(new_dir)),
                               f"跑步助手_补丁_{ver}.zip")

        man, path = make_patch(old_dir, new_dir, out, args.notes)
        size = os.path.getsize(path)
        full = sum(s for _, s in _walk(new_dir).values())
        st = man["stats"]
        print("═" * 52)
        print(f"√ 差量包：{path}")
        print(f"  {man['from_version'] or '?'} → {man['to_version'] or '?'}")
        print(f"  变化 {st['changed']} 个（新增 {st['added']}） · "
              f"淘汰 {st['removed']} 个 · 未变 {st['same']} 个")
        print(f"  补丁 {size / 1024 / 1024:.2f} MB "
              f"（完整解包 {full / 1024 / 1024:.1f} MB，"
              f"省 {100 - size / max(1, full) * 100:.0f}%）")
        print("═" * 52)
        for rel in man["files"][:30]:
            print("   +", rel)
        if len(man["files"]) > 30:
            print(f"   … 另有 {len(man['files']) - 30} 个")
        for rel in man["delete"][:10]:
            print("   -", rel)
        return 0
    finally:
        shutil.rmtree(work, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
