﻿# -*- coding: utf-8 -*-
# 跑步助手 · 一键更新 / 一键安装
#   用法：
#     update_runner.ps1                 # 自动找最新的发布包，覆盖安装（保留 .funsport）
#     update_runner.ps1 -Zip <zip路径>  # 指定发布包或差量补丁
#     update_runner.ps1 -Target <目录>  # 指定安装目录（默认 D:\软件\跑步助手）
#     update_runner.ps1 -NoLaunch       # 更新完不自动启动
# 设计要点：
#   1) 只镜像程序文件，.funsport（账号/会话/配置）永远保留；
#   2) 目标目录不存在时自动当"全新安装"，并建桌面快捷方式；
#   3) 旧版残留文件（_internal 里被删掉的模块）会被清掉，不用手动全删；
#   4) 发布包里没有 跑步助手.exe 就中止，绝不先清空再失败；
#   5) 包里带 patch.json 时自动走**差量模式**：只覆盖清单里的文件、
#      删除清单里淘汰的文件，其余原样保留 —— 补丁通常只有几 MB。

param(
    [string]$Zip = "",
    [string]$Target = "D:\软件\跑步助手",
    [switch]$NoLaunch
)

$ErrorActionPreference = "Stop"
$APP = "跑步助手"
$EXE = "$APP.exe"

function Say($msg, $color = "Gray") { Write-Host $msg -ForegroundColor $color }
function Fail($msg) { Write-Host "× $msg" -ForegroundColor Red; exit 1 }

Say ""
Say "═══ $APP · 一键更新 ═══" "Cyan"
Say ""

# ── 1. 找发布包 ────────────────────────────────────────────
if (-not $Zip) {
    $cands = @()
    $here = $PSScriptRoot
    if ($here) {
        $cands += Get-ChildItem -Path $here -Filter "*发布版*.zip" -File -ErrorAction SilentlyContinue
    }
    if (Test-Path $Target) {
        $cands += Get-ChildItem -Path $Target -Filter "*发布版*.zip" -File -ErrorAction SilentlyContinue
    }
    foreach ($d in @("D:\deepseek工作区间", "$env:USERPROFILE\Downloads", "$env:USERPROFILE\Desktop")) {
        if (Test-Path $d) {
            $cands += Get-ChildItem -Path $d -Filter "*发布版*.zip" -File -ErrorAction SilentlyContinue
            $cands += Get-ChildItem -Path $d -Filter "$APP*.zip" -File -ErrorAction SilentlyContinue
        }
    }
    $cands = $cands | Sort-Object LastWriteTime -Descending
    if ($cands.Count -gt 0) {
        $Zip = $cands[0].FullName
        Say "→ 自动选中最新发布包：$Zip" "DarkGray"
    }
}
if (-not $Zip -or -not (Test-Path $Zip)) {
    Fail "没找到发布包。把 跑步助手_发布版.zip 拖到这个 bat 上，或放在 D:\deepseek工作区间\"
}
$Zip = (Resolve-Path $Zip).Path
$zipTime = (Get-Item $Zip).LastWriteTime
$zipMB = [math]::Round((Get-Item $Zip).Length / 1MB, 1)
Say "→ 发布包：$Zip（$zipMB MB，$($zipTime.ToString('yyyy-MM-dd HH:mm'))）"

# ── 2. 解包到临时目录并校验 ───────────────────────────────
$tmp = Join-Path $env:TEMP ("fs_upd_" + [guid]::NewGuid().ToString("N").Substring(0, 8))
New-Item -ItemType Directory -Path $tmp -Force | Out-Null
Say "→ 解包中…"
try {
    Expand-Archive -Path $Zip -DestinationPath $tmp -Force
} catch {
    Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
    Fail "解包失败：$($_.Exception.Message)"
}
$src = $tmp
$patchFile = Join-Path $tmp "patch.json"
$isPatch = Test-Path $patchFile
if (-not $isPatch) {
    if (-not (Test-Path (Join-Path $src $EXE))) {
        # 压缩包里可能多套了一层目录
        $found = Get-ChildItem -Path $tmp -Recurse -Filter $EXE -File -ErrorAction SilentlyContinue |
                 Select-Object -First 1
        if ($found) { $src = $found.Directory.FullName }
    }
    if (-not (Test-Path (Join-Path $src $EXE))) {
        # 也许是差量包，patch.json 藏在子目录里
        $pf = Get-ChildItem -Path $tmp -Recurse -Filter "patch.json" -File -ErrorAction SilentlyContinue |
              Select-Object -First 1
        if ($pf) { $src = $pf.Directory.FullName; $patchFile = $pf.FullName; $isPatch = $true }
    }
    if (-not $isPatch -and -not (Test-Path (Join-Path $src $EXE))) {
        Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
        Fail "发布包里没有 $EXE（也不是差量补丁），已中止（什么都没改）"
    }
}
if ($isPatch) { Say "→ 检测到差量补丁，走增量更新模式" "Cyan" }

# ── 3. 关闭正在运行的程序 ─────────────────────────────────
$procs = Get-Process -Name $APP -ErrorAction SilentlyContinue
if ($procs) {
    Say "→ 关闭正在运行的 $APP…"
    $procs | ForEach-Object { try { $_.CloseMainWindow() | Out-Null } catch {} }
    Start-Sleep -Milliseconds 800
    Get-Process -Name $APP -ErrorAction SilentlyContinue |
        ForEach-Object { try { $_.Kill() } catch {} }
    Start-Sleep -Milliseconds 400
}

# ── 4. 目标目录：新建 or 更新 ─────────────────────────────
$fresh = -not (Test-Path $Target)
if ($fresh) {
    Say "→ 目标目录不存在，按全新安装处理：$Target"
    New-Item -ItemType Directory -Path $Target -Force | Out-Null
} else {
    Say "→ 覆盖安装到：$Target（保留 .funsport 账号数据）"
}

# ── 5. 镜像复制（排除 .funsport）───────────────────────────
if ($isPatch) {
    # 差量模式：只覆盖清单里的文件 + 删除淘汰文件，其余不动
    Say "→ 应用差量补丁…"
    try {
        $man = Get-Content $patchFile -Raw -Encoding UTF8 | ConvertFrom-Json
    } catch {
        Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
        Fail "patch.json 解析失败：$($_.Exception.Message)"
    }
    Say ("  版本 {0} → {1}，变化 {2} 个，淘汰 {3} 个" -f `
        $man.from_version, $man.to_version, $man.files.Count, $man.delete.Count) "DarkGray"

    $n = 0
    foreach ($rel in $man.files) {
        $s = Join-Path $src $rel
        $d = Join-Path $Target $rel
        if (-not (Test-Path $s)) { Say "  ! 跳过缺失文件：$rel" "Yellow"; continue }
        $dd = Split-Path $d -Parent
        if (-not (Test-Path $dd)) { New-Item -ItemType Directory -Path $dd -Force | Out-Null }
        try { Copy-Item $s $d -Force; $n++ }
        catch { Say "  ! 覆盖失败：$rel（$($_.Exception.Message)）" "Yellow" }
    }
    $del = 0
    foreach ($rel in $man.delete) {
        $d = Join-Path $Target $rel
        if (Test-Path $d) {
            try { Remove-Item $d -Force -Recurse -ErrorAction Stop; $del++ } catch {}
        }
    }
    Say "  √ 已写入 $n 个文件，清理 $del 个淘汰文件" "Green"
    $rc = 0
} else {
    Say "→ 复制程序文件…"
    $log = Join-Path $env:TEMP "fs_robocopy.log"
    $rc = Start-Process -FilePath "robocopy.exe" `
        -ArgumentList @(
            "`"$src`"", "`"$Target`"",
            "/MIR", "/XD", "`"$Target\.funsport`"",
            "/NFL", "/NDL", "/NJH", "/NJS", "/R:2", "/W:1",
            "/LOG:`"$log`""
        ) -Wait -PassThru -WindowStyle Hidden
    if ($rc.ExitCode -ge 8) {
        Say "× 复制过程有错误（robocopy code $($rc.ExitCode)），日志：$log" "Red"
        Get-Content $log -Tail 20 | ForEach-Object { Say "  $_" "DarkGray" }
        Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
        exit 1
    }
}

# ── 6. 确保数据目录存在（首次安装）─────────────────────────
$data = Join-Path $Target ".funsport"
if (-not (Test-Path $data)) { New-Item -ItemType Directory -Path $data -Force | Out-Null }

# ── 7. 记录版本 ───────────────────────────────────────────
$exePath = Join-Path $Target $EXE
$verFile = Join-Path $Target "version.json"
$ver = (Get-Item $exePath).LastWriteTime.ToString("yyyy-MM-dd HH:mm")
$obj = [ordered]@{
    version   = $ver
    exe_size  = (Get-Item $exePath).Length
    installed = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    source    = $Zip
}
try {
    ($obj | ConvertTo-Json) | Set-Content -Path $verFile -Encoding UTF8
} catch {}

# ── 8. 全新安装时建桌面快捷方式 ───────────────────────────
$lnkPath = Join-Path ([Environment]::GetFolderPath("Desktop")) "$APP.lnk"
if ($fresh -or -not (Test-Path $lnkPath)) {
    try {
        $ws = New-Object -ComObject WScript.Shell
        $lnk = $ws.CreateShortcut($lnkPath)
        $lnk.TargetPath = $exePath
        $lnk.WorkingDirectory = $Target
        $lnk.IconLocation = "$exePath,0"
        $lnk.Description = "$APP（双击启动）"
        $lnk.Save()
        Say "→ 已创建桌面快捷方式：$lnkPath"
    } catch {
        Say "! 快捷方式创建失败（不影响使用）：$($_.Exception.Message)" "Yellow"
    }
}

Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue

Say ""
Say "√ 完成：$Target" "Green"
Say "  · 程序版本：$ver"
Say "  · 账号数据：$data（未动）"
Say ""

# ── 9. 启动 ───────────────────────────────────────────────
if (-not $NoLaunch) {
    Say "→ 启动 $APP…" "DarkGray"
    try { Start-Process -FilePath $exePath -WorkingDirectory $Target } catch {
        Say "! 启动失败，手动双击桌面图标即可" "Yellow"
    }
}
Say "窗口可以关掉了。" "DarkGray"
if ($Host.Name -eq "ConsoleHost" -and -not $env:FS_NO_PAUSE) {
    Start-Sleep -Seconds 2
}
